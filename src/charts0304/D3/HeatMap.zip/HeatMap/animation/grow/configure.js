import React, { Component } from 'react'

export default class configure extends Component {
    render() {
        return (
            <div>
                grow configure
            </div>
        )
    }
}
